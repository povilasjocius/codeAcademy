import UIKit

var myFriendlyGreeting: String = "Hello, my Friends"

print(myFriendlyGreeting)

